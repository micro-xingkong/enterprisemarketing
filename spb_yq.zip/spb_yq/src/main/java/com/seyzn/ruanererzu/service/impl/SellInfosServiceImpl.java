package com.seyzn.ruanererzu.service.impl;

import com.seyzn.ruanererzu.domain.SellInfosEntity;
import com.seyzn.ruanererzu.mapper.SellInfosMapper;
import com.seyzn.ruanererzu.service.SellInfosService;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import javax.annotation.Resource;

/**
 * (SellInfos)表服务实现类
 *
 * @author ywb
 * @since 2023-06-29 19:23:21
 */
@Service("sellInfosService")
public class SellInfosServiceImpl implements SellInfosService {
    private static int PAGE_DEFAULT = 1;
    private static int SIZE_DEFAULT = 10;
    @Resource
    private SellInfosMapper sellInfosMapper;

    /**
     * 通过ID查询单条数据
     *
     * @param sellId 主键
     * @return 实例对象
     */
    @Override
    public SellInfosEntity queryById(Integer sellId) {
        return this.sellInfosMapper.queryById(sellId);
    }

    /**
     * 分页查询
     *
     * @param sellInfos 筛选条件
     * @param pageRequest      分页对象
     * @return 查询结果
     */
    @Override
    public Page<SellInfosEntity> queryByPage(SellInfosEntity sellInfos, Integer page, Integer size, String orderCol, String orderDirect) {
        if(page == null || page <= 0){
            page = PAGE_DEFAULT;
        }
        if(size == null || size <= 0){
            size = SIZE_DEFAULT;
        }

        Sort sort = null;
        if(orderCol != null) {
            Sort.Order order = new Sort.Order(("DESC".equals(orderDirect) ? Sort.Direction.DESC : Sort.Direction.ASC), orderCol);
            sort = Sort.by(order);
        }

        PageRequest pageRequest = PageRequest.of(page - 1, size);
        if(sort != null){
            pageRequest = PageRequest.of(page - 1, size, sort);
        }
        
        long total = this.sellInfosMapper.count(sellInfos);
        
        return new PageImpl<>(this.sellInfosMapper.queryAllByLimit(sellInfos, pageRequest), pageRequest, total);
    }

    /**
     * 新增数据
     *
     * @param sellInfos 实例对象
     * @return 实例对象
     */
    @Override
    public boolean insert(SellInfosEntity sellInfos) {
        return this.sellInfosMapper.insert(sellInfos) > 0;
    }

    /**
     * 修改数据
     *
     * @param sellInfos 实例对象
     * @return 实例对象
     */
    @Override
    public boolean update(SellInfosEntity sellInfos) {
       return this.sellInfosMapper.update(sellInfos) > 0;
    }

    /**
     * 通过主键删除数据
     *
     * @param sellId 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Integer sellId) {
        return this.sellInfosMapper.deleteById(sellId) > 0;
    }
}
