package com.seyzn.ruanererzu.domain;

import java.util.Date;
import java.io.Serializable;
import lombok.Data;

/**
 * (SellInfos)实体类
 *
 * @author ywb
 * @since 2023-06-29 19:23:21
 */
@Data
public class SellInfosEntity implements Serializable {
    private static final long serialVersionUID = -92634583446164718L;
    
    private Integer sellId;
    
    private Integer userId;
    
    private Integer proId;
    
    private Integer cusId;
    
    private Date sellTime;
    
    private String sellDesc;
    
    private Object sellCount;

}

